./install.sh

sleep 25

sdb root on
sleep 2
sdb shell touch /opt/share/askuser_disable
sdb shell ls /opt/share
sdb shell exit
