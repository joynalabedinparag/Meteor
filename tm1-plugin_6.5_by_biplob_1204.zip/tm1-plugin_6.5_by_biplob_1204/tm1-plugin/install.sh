autotest=$1
sdb -d root on
sdb -d shell mount -o remount,rw /

echo -e "\n\n----- Push library files (sdb push)-----"
tmpdir="/tmp/tmp_plugin"
sdb -d shell mkdir -p $tmpdir
sdb -d push camera-interface/*.rpm $tmpdir
sdb -d push connectivity/*.rpm $tmpdir
sdb -d push gstreamer/*.rpm $tmpdir
sdb -d push system-freezer/*.rpm $tmpdir
sdb -d push system-freezer/.debugmode /opt/etc/
sdb -d push system-info/*.rpm $tmpdir
sdb -d push radio-hal/*.rpm $tmpdir

if [ "$autotest" != "auto-test" ];then
	sdb -d push location/*.rpm $tmpdir
fi
echo -e "\n\n----- Install libraries -----"
sdb -d shell rpm -ivh --force --nodeps $tmpdir/*.rpm
sdb -d shell rm -rf $tmpdir

echo -e "\n\n----- Install GL DDK -----"
ddk_tmpdir="/tmp/pkg"
sdb -d shell mkdir -p $ddk_tmpdir
sdb -d push gl-ddk/pkg/*.rpm $ddk_tmpdir
sdb -d shell rpm -ivh --force $ddk_tmpdir/*.rpm
sdb -d shell rm -rf $ddk_tmpdir
sdb -d push gl-ddk/conf/99-GPU-Acceleration.rules /etc/udev/rules.d/
sdb -d shell sync
sdb -d shell chsmack -a "_" /usr/lib/bufmgr/*

echo -e "\n\n----- Install TRM -----"
trm_tmpdir="/tmp/trm_pkg"
bincfg="bincfg-1.0.1-1.armv7l"
trm="trm-0.0.31-0.armv7l"
sdb -d shell mkdir -p $trm_tmpdir
sdb -d push trm/*.rpm $trm_tmpdir
sdb -d shell rpm -e --nodeps $bincfg
sdb -d shell rpm -e --nodeps $trm
sdb -d shell rpm -ivh --force $trm_tmpdir/*.rpm
sdb -d shell rm -rf $trm_tmpdir

echo -e "\n\n----- Install GDB Extension -----"
sdb -d push gdb-extensions/gdb-dashboard /root/.gdbinit
sdb -d push gdb-extensions/gdb-heap /root/.gdb-heap

echo -e "\n\n----- fstrim -----"
sdb -d shell fstrim -a
sleep 1

echo -e "\n\n----- Sync & Reboot -----\n"
sdb -d shell sync
sdb -d shell reboot -f
