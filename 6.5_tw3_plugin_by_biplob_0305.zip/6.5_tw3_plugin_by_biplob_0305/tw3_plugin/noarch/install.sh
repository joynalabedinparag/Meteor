#
# Add only noarch packages here
#

# change to local directory
LOCALPATH=`dirname $0`
cd ${LOCALPATH}

echo -e "\n\n----- Push noarch rpm files (sdb push)-----"
tmpdir="/tmp/plugin_noarch"
sdb -d shell mkdir -p $tmpdir

# noarch packages

# Firmware for MFC video codec
sdb -d push video-codec/*.rpm $tmpdir
sdb -d push audio/*.rpm $tmpdir

echo -e "\n\n----- Install noarch rpm files -----"
sdb -d shell rpm -ivh --force --nodeps $tmpdir/*.rpm
sdb -d shell rm -rf $tmpdir

#
# Do not add reboot command here, it will be done in the upper layer
#
