sdb -d root on
sdb -d shell mount -o remount,rw /

# check target has /usr/lib64
if [ `sdb -d shell "ls /usr/lib64 2>/dev/null" | wc -l` -eq 0 ]; then
	ARCH=32
else
	ARCH=64
fi

echo -e "----- Target is ARM${ARCH} -----\n"

./noarch/install.sh
./${ARCH}bit/install.sh

echo -e "\n\n----- fstrim -----"
sdb -d shell fstrim -a
sleep 1

echo -e "\n\n----- Sync & Reboot -----\n"
sdb -d shell sync
sdb -d shell reboot -f
