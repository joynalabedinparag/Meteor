#
# Add only ARM 64bit packages here
#

# change to local directory
LOCALPATH=`dirname $0`
cd ${LOCALPATH}

# 64bit pacakges
echo -e "\n\n----- ARM 64bit rpm files -----"

echo -e "\n\n----- Push library files (sdb push) -----"
tmpdir="/tmp/tmp_plugin"
sdb -d shell mkdir -p $tmpdir
#sdb -d push connectivity/*.rpm $tmpdir
#sdb -d push system-freezer/*.rpm $tmpdir

echo -e "\n\n----- Install libraries -----"
sdb -d shell rpm -ivh --force --nodeps $tmpdir/*.rpm
sdb -d shell rm -rf $tmpdir

echo -e "\n\n----- Install GL DDK -----"
ddk_tmpdir="/tmp/pkg"
sdb -d shell mkdir -p $ddk_tmpdir
sdb -d push gl-ddk/conf/99-GPU-Acceleration.rules /etc/udev/rules.d/
sdb -d push gl-ddk/pkg/*.rpm $ddk_tmpdir
sdb -d shell rpm -ivh --force --nodeps $ddk_tmpdir/*.rpm
sdb -d shell chsmack -a "_" /usr/lib/bufmgr/*
sdb -d shell sync
sdb -d shell rm -rf $ddk_tmpdir

#
# Do not add reboot command here, it will be done in the upper layer
#
